/*
 * Copyright by the original author or authors
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

//�߿�!!! transaction �����ɴ�
package wallettemplate;

import javafx.scene.layout.HBox;

import org.bitcoinj.core.*;
import org.bitcoinj.wallet.SendRequest;
import org.bitcoinj.wallet.Wallet;

import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.sun.javafx.collections.MappingChange.Map;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import org.spongycastle.crypto.params.KeyParameter;
import wallettemplate.controls.BitcoinAddressValidator;
import wallettemplate.utils.TextFieldValidator;
import wallettemplate.utils.WTUtils;

import static com.google.common.base.Preconditions.checkState;
import static wallettemplate.utils.GuiUtils.*;

import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.ResourceBundle;

import javax.annotation.Nullable;
import javax.swing.JButton;
import javax.swing.JRadioButton;

public class SendMoneyController implements Initializable {
    public Button sendBtn;
    public Button cancelBtn;
    public TextField address;
    public Label titleLabel;
    public Label firstcandi;
    public Label secondcandi;
    public Label thirdcandi;
    public Label fourthcandi;
    public RadioButton radio1;
    public RadioButton radio2;
    public RadioButton radio3;
    public RadioButton radio4;
    public Label scandi;
    public TextField amountEdit;
    public Label btcLabel;

    public Main.OverlayUI overlayUI;

    private Wallet.SendResult sendResult;
    private KeyParameter aesKey;
    //////////////////////////////////////////////////////////////////////////////
    //hashmap �ĺ��� �̸�,�ּ� ������ ����
    public HashMap<String,String> Hmap = new HashMap<String,String>();
    @FXML
    private ComboBox<String> Caddress;//�޺��ڽ�
    private ObservableList<String> list = FXCollections.observableArrayList();
    
    // Called by FXMLLoader
    public void initialize() {//maincontroller���� �ҷ��� , �޺��ڽ� ������ �� ������ �Ʒ��� initialize�� �Ѵ�
        Coin balance = Main.bitcoin.wallet().getBalance();//getbalance = AVAILABLEã��
        checkState(!balance.isZero());
        new TextFieldValidator(amountEdit, text ->
                !WTUtils.didThrow(() -> checkState(Coin.parseCoin(text).compareTo(balance) <= 0)));
        amountEdit.setText(balance.toPlainString());
        hinit();
        new BitcoinAddressValidator(Main.params, scandi ,Hmap, sendBtn);
    }
    
    public void cancel(ActionEvent event) {
        overlayUI.done();
    }

    public void send(ActionEvent event) {//�߿�!!
        // Address exception cannot happen as we validated it beforehand.
    	// �ּ� ��ȿ�� �˻�� ������ ��ȿ���� �˻� �����Ƿ� �߻��� �� �����ϴ�.
        try {
            Coin amount = Coin.parseCoin("1.0");
            Address destination = Address.fromBase58(Main.params, Hmap.get(scandi.getText()));
            System.out.println("address: " + destination);
            SendRequest req;
            if (amount.equals(Main.bitcoin.wallet().getBalance()))
                req = SendRequest.emptyWallet(destination);
            else
                req = SendRequest.to(destination, amount);
            req.aesKey = aesKey;
            //fee����
            //req.feePerKb =Coin.ZERO;
            //req.ensureMinRequiredFee = false;
            sendResult = Main.bitcoin.wallet().sendCoins(req);
            System.out.println(sendResult.tx.toString());
            Futures.addCallback(sendResult.broadcastComplete, new FutureCallback<Transaction>() {
                @Override
                public void onSuccess(@Nullable Transaction result) {
                    checkGuiThread();
                    informationalAlert("��ǥ ����","Ʈ����� id��"+sendResult.tx.toString(),0);
                    overlayUI.done();
                }

                @Override
                public void onFailure(Throwable t) {
                    // We died trying to empty the wallet.
                    crashAlert(t);
                }
            });
            sendResult.tx.getConfidence().addEventListener((tx, reason) -> {
                if (reason == TransactionConfidence.Listener.ChangeReason.SEEN_PEERS)
                    updateTitleForBroadcast();
            });
            updateTitleForBroadcast();
        }catch (InsufficientMoneyException e) {
            informationalAlert("Could not empty the wallet",
                    "You may have too little money left in the wallet to make a transaction.",0);
            overlayUI.done();
        } catch (ECKey.KeyIsEncryptedException e) {
        }
    }


    private void updateTitleForBroadcast() {
        final int peers = sendResult.tx.getConfidence().numBroadcastPeers();
        //titleLabel.setText(String.format("Broadcasting ... seen by %d peers", peers));
    }

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {//�� ����
		Coin balance = Main.bitcoin.wallet().getBalance();//getbalance = AVAILABLEã��
        checkState(!balance.isZero()); //�� �������� �Ѿ�� �����̶�� Coin�� 0�� �ƴ����� �ѹ� �� �˻�
        hinit();//�ĺ��� �ּ� ����
        //Caddress.setItems(list);
        //��Ʈ���� �ּ��� ��ȿ�� �˻�, ���� ���� send������ ��ȿ���� �˻����� �ʴ´�
        new BitcoinAddressValidator(Main.params, scandi ,Hmap, sendBtn);//���� ��ȿ�� �˻翡 ������ ��� send��ư�� ��Ȱ��ȭ
	}
	
	public void hinit() {//���� �� �޾ƿ� �ĺ���,�ּ� ����
		int size = Main.Clist.size();
		if(size < 1) {
			radio1.setDisable(true);
		}
		else firstcandi.setText(Main.Clist.get(0));
		if(size < 2) {
			radio2.setDisable(true);
		}
		else secondcandi.setText(Main.Clist.get(1));
		if(size < 3) {
			radio3.setDisable(true);
		}
		else thirdcandi.setText(Main.Clist.get(2));
		if(size < 4) {
			radio4.setDisable(true);
		}
		else fourthcandi.setText(Main.Clist.get(3));
		
		Hmap.put("Label","0");
		for(int i=0; i<Main.Clist.size(); i++) {
			Hmap.put(Main.Clist.get(i),Main.CAlist.get(i));
		}
	}
	
	public void rclick1() {
		scandi.setText(firstcandi.getText());
	}
	public void rclick2() {
		scandi.setText(secondcandi.getText());
	}
	public void rclick3() {
		scandi.setText(thirdcandi.getText());
	}
	public void rclick4() {
		scandi.setText(fourthcandi.getText());
	}
}
